This is the server that was provided. Since the original repo is only available for students who have access to the university's gitlab, I've put it here so that YOU can access it and test the client for your self if you want.

A couple of small modifications have been brought to the server, but nothing major. You can check them out in the commits log.

To use this server along side the client, copy it, then run the following command to install it in your local maven repository:

```bash
mvn clean install
```

Then it can be used as a dependency in the client side.

To run the server, you need to specify a configuration file. A standard one is provided in the repo. You can run the server with the following command:

```bash
mvn clean compile exec:java -Dexec.args="-c ./maznet.prop"
```
package de.fhac.mazenet.server.userinterface.mazeFX.data;

/**
 * Created by Richard Zameitat on 02.08.2016.
 */
public class Wrapper<T> {
	public T val;

	public Wrapper(T val){
		this.val = val;
	}
}

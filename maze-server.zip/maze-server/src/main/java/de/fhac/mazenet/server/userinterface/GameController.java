package de.fhac.mazenet.server.userinterface;

public interface GameController {
    void startGame();

    void stopGame();
}
